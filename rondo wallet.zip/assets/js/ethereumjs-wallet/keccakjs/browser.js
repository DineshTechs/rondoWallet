module.exports = require('browserify-sha3').SHA3Hash
