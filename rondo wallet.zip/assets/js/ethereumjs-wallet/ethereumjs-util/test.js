const util = require('./')
const BN = util.BN
const a = new BN(23)

console.log(a.toBuffer())
