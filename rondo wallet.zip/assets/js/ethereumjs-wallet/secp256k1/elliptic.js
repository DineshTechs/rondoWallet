'use strict'
module.exports = require('./lib')(require('./lib/elliptic'))
