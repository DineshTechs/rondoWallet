# v0.3.1 / 2015-05-22

* Fixed bugs.

# v0.3.0 / 2015-05-21

* Support byte array and ArrayBuffer input.

# v0.2.0 / 2015-04-04

* Implement NIST's May 2014 SHA-3 version.
* Rename original methods to keccak.

# v0.1.2 / 2015-02-27

* Improve performance.

# v0.1.1 / 2015-02-26

* Improve performance.

# v0.1.0 / 2015-02-23

* Initial release
