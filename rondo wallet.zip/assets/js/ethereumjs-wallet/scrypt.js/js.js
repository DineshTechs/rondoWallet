module.exports = require('scryptsy')
