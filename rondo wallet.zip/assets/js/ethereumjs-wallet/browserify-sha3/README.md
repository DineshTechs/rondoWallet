# browserify-sha3 [![Build Status](https://travis-ci.org/wanderer/browserify-sha3.svg)](https://travis-ci.org/wanderer/browserify-sha3)
[node-sha3](https://github.com/phusion/node-sha3) compatability for browserify
